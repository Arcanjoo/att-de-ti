import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
  
public class att { 
  
    public static void main(String[] args) { 
        String url = "jdbc:mysql://localhost:3306/jogos"; 
        String user = "root"; // Usuário padrão do MySQL 
        String password = ""; // Senha do MySQL (vazia por padrão no XAMPP) 
  
        try { 
            // Carregar o driver JDBC do MySQL 
            Class.forName("com.mysql.cj.jdbc.Driver");  
  
            try ( // Estabelecer conexão
                    Connection conn = DriverManager.getConnection(url, user, password)) {
                System.out.println("Conectado ao banco de dados!");
                // Exemplo: Inserir um dado na tabela
                String sqlInsert = "INSERT INTO games (nome_jogo) VALUES (?)";
                PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert);
                pstmtInsert.setString(1, "call of duty");
                pstmtInsert.executeUpdate();
                System.out.println("Registro inserido com sucesso!");
                // Exemplo: Consultar dados da tabela
                String sqlSelect = "SELECT * FROM games";
                PreparedStatement pstmtSelect = conn.prepareStatement(sqlSelect);
                ResultSet rs = pstmtSelect.executeQuery();
                while (rs.next()) {
                    int id = rs.getInt("id_jogo");
                    String nome = rs.getString("nome_jogo");
                    System.out.println("ID: " + id + ", Nome: " + nome);
                }
                // Fechar conexão
            } 
        } catch (Exception e) { 
            e.printStackTrace(); 
        } 
    } 
}
